export default function SearchDefault() {
  return null;
}
