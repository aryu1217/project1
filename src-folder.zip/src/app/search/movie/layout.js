export default function SearchMovieLayout({ modal, children }) {
  return (
    <>
      {children}
      {modal}
    </>
  );
}
