export default function SearchLayout({ modal, children }) {
  return (
    <>
      {children}
      {modal}
    </>
  );
}
