export default function SearchDramaLayout({ modal, children }) {
  return (
    <>
      {children}
      {modal}
    </>
  );
}
