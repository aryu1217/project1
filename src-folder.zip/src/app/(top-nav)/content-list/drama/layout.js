export default function DramaLayout({ modal, children }) {
  return (
    <>
      {children}
      {modal}
    </>
  );
}
