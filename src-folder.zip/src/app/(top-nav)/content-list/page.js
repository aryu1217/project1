export default function ContentListPage() {
  return <p> ha...</p>;
}
