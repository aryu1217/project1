export default function MovieLayout({ modal, children }) {
  return (
    <>
      {children}
      {modal}
    </>
  );
}
